from grocery_core import *
from datetime import date

def show(rows):
    if not rows:
        print("\nNo matching items.\n"); return
    print("\n"+"-"*96)
    print(f'{"ID":12} {"ITEM":22} {"CATEGORY":13} {"QTY":10} {"STATUS":12} {"DUE":12}')
    print("-"*96)
    for r in rows:
        print(f'{r["id"][:12]:12} {r["item"][:22]:22} {r["category"][:13]:13} {(r["quantity"]+" "+r["unit"])[:10]:10} {("Bought" if r["purchased"] else "Pending"):12} {r["due_date"]:12}')
    print("-"*96)

def ask(prompt, default=None):
    value=input(prompt).strip()
    return value if value else default

def main():
    records=load_json()
    while True:
        print("""
╔══════════════════════════════════════════════╗
║          GROCERY LIST GENERATOR               ║
║        Project #69 | Food & Agriculture       ║
╚══════════════════════════════════════════════╝
 1. Generate list from a recipe
 2. Add a grocery item manually
 3. View all grocery items
 4. Search and filter items
 5. Mark item as purchased
 6. Executive summary and warnings
 7. Import legacy CSV dataset
 8. Export CSV, Markdown and TXT reports
 9. Reload saved data
 0. Exit
""")
        choice=ask("Choose an option: ")
        try:
            if choice=="1":
                recipes=load_recipes()
                print("\nAvailable recipes:")
                names=list(recipes)
                for i,n in enumerate(names,1): print(f" {i}. {n}")
                n=int(ask("Recipe number: "))
                if not 1<=n<=len(names): raise ValidationError("Choose a valid recipe number.")
                servings=int(ask("Number of servings (1-100): "))
                list_name=ask("Shopping list name [Meal Plan]: ","Meal Plan")
                added=generate_from_recipe(records,names[n-1],servings,list_name)
                print(f"\nAdded {len(added)} ingredients for {names[n-1]} ({servings} servings).")
            elif choice=="2":
                item=ask("Item name: "); cat=ask("Category (Vegetables/Fruits/Dairy/Grains/Pulses/Bakery/Pantry/Spices/Other): ")
                qty=ask("Quantity (positive number): "); unit=ask("Unit (kg/g/pieces/litre/etc.): ")
                lname=ask("List name [My Grocery List]: ","My Grocery List")
                due=ask(f"Due date YYYY-MM-DD [{date.today().isoformat()}]: ",date.today().isoformat())
                row=add_record(records,item,cat,qty,unit,lname,due); print("Saved:",row["item"])
            elif choice=="3": show(records)
            elif choice=="4":
                key=ask("Keyword (blank for all): ","")
                cat=ask("Category [All]: ","All")
                status=ask("Status All/Pending/Purchased [All]: ","All")
                if status not in {"All","Pending","Purchased"}: raise ValidationError("Status must be All, Pending or Purchased.")
                show(search_records(records,key,cat,"All",status))
            elif choice=="5":
                rid=ask("Enter item ID: ")
                found=next((r for r in records if r["id"]==rid),None)
                if not found: raise ValidationError("No item found with that ID.")
                found["purchased"]=True; save_records(records); print("Marked as purchased.")
            elif choice=="6":
                s=summary(records)
                print(f'\nTotal: {s["total_items"]} | Purchased: {s["purchased"]} | Pending: {s["pending"]}')
                print(f'Purchase rate: {s["purchase_rate"]}% | Average quantity: {s["average_quantity"]}')
                print("Category counts:",s["category_counts"])
                alerts=warnings(records)
                print("\nWarnings:")
                if alerts:
                    for a in alerts: print(f' [{a["level"]}] {a["message"]}')
                else: print(" No active warnings.")
            elif choice=="7":
                path=ask("CSV file path: ")
                accepted,errors=import_csv(path,records)
                print(f"Imported {len(accepted)} valid row(s); {len(errors)} error(s).")
                for e in errors: print(f' Row {e["row"]}: {e["error"]}')
            elif choice=="8":
                for p in export_all(records): print("Created:",p.relative_to(ROOT))
            elif choice=="9":
                records=load_json(); print(f"Reloaded {len(records)} record(s).")
            elif choice=="0":
                print("Thank you. Your data is saved locally."); break
            else: print("Choose a menu option from 0 to 9.")
        except (ValidationError,ValueError,TypeError) as exc:
            print("Input error:",exc)
        except KeyboardInterrupt:
            print("\nUse option 0 to exit safely.")
        input("\nPress Enter to return to the menu...")

if __name__=="__main__": main()
