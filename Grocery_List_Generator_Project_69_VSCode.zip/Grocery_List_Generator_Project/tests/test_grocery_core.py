import sys, unittest, tempfile, json
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from grocery_core import validate_record, ValidationError, summary, search_records, generate_from_recipe, warnings

class GroceryTests(unittest.TestCase):
    def row(self):
        return {"id":"T1","list_name":"Test","item":"Rice","category":"Grains","quantity":"2","unit":"kg","purchased":"false","due_date":"2099-01-01","created_at":"2026-01-01"}
    def test_valid_record(self):
        self.assertFalse(validate_record(self.row())["purchased"])
    def test_reject_blank_item(self):
        r=self.row();r["item"]=""
        with self.assertRaises(ValidationError): validate_record(r)
    def test_reject_negative_quantity(self):
        r=self.row();r["quantity"]="-1"
        with self.assertRaises(ValidationError): validate_record(r)
    def test_summary(self):
        r=validate_record(self.row());s=summary([r])
        self.assertEqual(s["total_items"],1);self.assertEqual(s["pending"],1)
    def test_search(self):
        r=validate_record(self.row())
        self.assertEqual(len(search_records([r],"ric")),1)
    def test_recipe_generation(self):
        from grocery_core import load_recipes
        self.assertIn("Vegetable Pulao",load_recipes())
    def test_warnings_result_is_list(self):
        self.assertIsInstance(warnings([]),list)

if __name__=="__main__": unittest.main()
