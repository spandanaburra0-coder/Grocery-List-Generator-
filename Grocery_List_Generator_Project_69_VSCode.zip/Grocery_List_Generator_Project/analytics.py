"""Pandas/NumPy analysis and Matplotlib chart helpers for the demo dashboard."""
from __future__ import annotations
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt


def records_frame(records):
    columns = ["id", "list_name", "item", "category", "quantity", "unit", "purchased", "due_date", "created_at"]
    frame = pd.DataFrame(records, columns=columns)
    if frame.empty:
        return frame
    frame["quantity_numeric"] = pd.to_numeric(frame["quantity"], errors="coerce").fillna(0.0)
    frame["created_at"] = pd.to_datetime(frame["created_at"], errors="coerce")
    frame["due_date"] = pd.to_datetime(frame["due_date"], errors="coerce")
    return frame


def analytics_metrics(records):
    frame = records_frame(records)
    if frame.empty:
        return {"total": 0, "purchased": 0, "pending": 0, "average_quantity": 0.0, "purchase_rate": 0.0}
    total = len(frame)
    purchased = int(frame["purchased"].astype(bool).sum())
    quantities = frame["quantity_numeric"].to_numpy(dtype=float)
    return {
        "total": total,
        "purchased": purchased,
        "pending": total - purchased,
        "average_quantity": round(float(np.mean(quantities)), 2) if quantities.size else 0.0,
        "purchase_rate": round((purchased / total) * 100, 1) if total else 0.0,
    }


def category_figure(records):
    frame = records_frame(records)
    fig, ax = plt.subplots(figsize=(8, 3.8))
    if frame.empty:
        ax.text(0.5, 0.5, "No data available", ha="center", va="center")
        ax.set_axis_off()
    else:
        counts = frame.groupby("category")["item"].count().sort_values(ascending=False)
        counts.plot(kind="bar", ax=ax)
        ax.set_title("Grocery items by category")
        ax.set_xlabel("Category")
        ax.set_ylabel("Number of items")
        ax.tick_params(axis="x", rotation=30)
        fig.tight_layout()
    return fig


def daily_trend_figure(records):
    frame = records_frame(records)
    fig, ax = plt.subplots(figsize=(8, 3.2))
    if frame.empty or frame["created_at"].notna().sum() == 0:
        ax.text(0.5, 0.5, "No dated records available", ha="center", va="center")
        ax.set_axis_off()
    else:
        trend = frame.dropna(subset=["created_at"]).groupby(frame.dropna(subset=["created_at"])["created_at"].dt.date).size()
        trend.plot(kind="line", marker="o", ax=ax)
        ax.set_title("List entries created over time")
        ax.set_xlabel("Date")
        ax.set_ylabel("New entries")
        ax.tick_params(axis="x", rotation=30)
        fig.tight_layout()
    return fig
