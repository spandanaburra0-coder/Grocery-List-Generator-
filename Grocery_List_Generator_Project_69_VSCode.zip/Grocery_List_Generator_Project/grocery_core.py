from __future__ import annotations
import csv, json, uuid
from pathlib import Path
from datetime import date, datetime
from collections import defaultdict

ROOT = Path(__file__).resolve().parent
DATA = ROOT / "data"
EXPORTS = ROOT / "exports"
REQUIRED = {"id","list_name","item","category","quantity","unit","purchased","due_date","created_at"}
CATEGORIES = ["Vegetables","Fruits","Dairy","Grains","Pulses","Bakery","Pantry","Spices","Other"]
CATEGORY_LIMITS = {"Vegetables":10,"Fruits":10,"Dairy":8,"Grains":10,"Pulses":8,"Bakery":5,"Pantry":8,"Spices":3,"Other":10}

class ValidationError(ValueError):
    pass

def load_json(path=None):
    path = Path(path or DATA/"records.json")
    try:
        if not path.exists(): return []
        data=json.loads(path.read_text(encoding="utf-8"))
        if not isinstance(data,list): raise ValidationError("JSON root must be a list.")
        return data
    except (json.JSONDecodeError, OSError) as exc:
        raise ValidationError(f"Could not read records JSON: {exc}") from exc

def save_records(records):
    DATA.mkdir(parents=True,exist_ok=True)
    tmp=DATA/"records.json.tmp"
    tmp.write_text(json.dumps(records,indent=2),encoding="utf-8")
    tmp.replace(DATA/"records.json")
    with (DATA/"records.csv").open("w",newline="",encoding="utf-8") as f:
        w=csv.DictWriter(f,fieldnames=list(REQUIRED)); w.writeheader()
        for r in records: w.writerow({**r,"purchased":str(bool(r["purchased"])).lower()})

def validate_record(row):
    cleaned={k:str(row.get(k,"")).strip() for k in REQUIRED}
    for field in ("list_name","item","category","unit","quantity"):
        if not cleaned[field]: raise ValidationError(f"{field} cannot be blank.")
    try: q=float(cleaned["quantity"])
    except ValueError: raise ValidationError("quantity must be numeric.")
    if q<=0 or q>100000: raise ValidationError("quantity must be greater than 0 and at most 100000.")
    try: date.fromisoformat(cleaned["due_date"])
    except ValueError: raise ValidationError("due_date must use YYYY-MM-DD.")
    try: date.fromisoformat(cleaned["created_at"])
    except ValueError: raise ValidationError("created_at must use YYYY-MM-DD.")
    if cleaned["purchased"].lower() not in {"true","false","1","0","yes","no"}:
        raise ValidationError("purchased must be true/false.")
    cleaned["purchased"]=cleaned["purchased"].lower() in {"true","1","yes"}
    cleaned["quantity"]=str(q).rstrip("0").rstrip(".") if "." in str(q) else str(q)
    return cleaned

def add_record(records, item, category, quantity, unit, list_name="My Grocery List", due_date=None):
    row={"id":"GL-"+uuid.uuid4().hex[:8].upper(),"list_name":list_name,"item":item,
         "category":category,"quantity":quantity,"unit":unit,"purchased":False,
         "due_date":due_date or date.today().isoformat(),"created_at":date.today().isoformat()}
    row=validate_record(row); records.append(row); save_records(records); return row

def load_recipes():
    path=DATA/"recipes.json"
    try: return json.loads(path.read_text(encoding="utf-8"))
    except (OSError,json.JSONDecodeError) as exc: raise ValidationError(f"Recipe file error: {exc}")

def generate_from_recipe(records, recipe_name, servings, list_name):
    recipes=load_recipes()
    if recipe_name not in recipes: raise ValidationError("Recipe not found.")
    try: servings=int(servings)
    except (ValueError,TypeError): raise ValidationError("Servings must be a whole number.")
    if not 1<=servings<=100: raise ValidationError("Servings must be between 1 and 100.")
    recipe=recipes[recipe_name]; factor=servings/recipe["servings"]
    added=[]
    for name,cat,qty,unit in recipe["ingredients"]:
        amount=round(float(qty)*factor,2)
        added.append({"id":"GL-"+uuid.uuid4().hex[:8].upper(),"list_name":list_name,
          "item":name,"category":cat,"quantity":str(amount),"unit":unit,"purchased":False,
          "due_date":date.today().isoformat(),"created_at":date.today().isoformat()})
    records.extend(added); save_records(records); return added

def search_records(records, keyword="", category="All", list_name="All", status="All"):
    key=keyword.casefold().strip(); out=[]
    for r in records:
        if key and key not in (r["item"]+" "+r["category"]+" "+r["list_name"]).casefold(): continue
        if category!="All" and r["category"]!=category: continue
        if list_name!="All" and r["list_name"]!=list_name: continue
        if status=="Pending" and r["purchased"]: continue
        if status=="Purchased" and not r["purchased"]: continue
        out.append(r)
    return out

def summary(records):
    total=len(records); purchased=sum(bool(r["purchased"]) for r in records)
    pending=total-purchased
    quantities=defaultdict(float); counts=defaultdict(int)
    for r in records:
        try: quantities[r["category"]]+=float(r["quantity"])
        except (ValueError,TypeError): pass
        counts[r["category"]]+=1
    return {"total_items":total,"purchased":purchased,"pending":pending,
      "purchase_rate":round((purchased/total*100) if total else 0,1),
      "average_quantity":round(sum(float(r["quantity"]) for r in records)/total,2) if total else 0,
      "category_counts":dict(counts),"category_quantities":dict(quantities)}

def warnings(records, today=None):
    today=today or date.today(); result=[]
    for r in records:
        if not r["purchased"]:
            try:
                due=date.fromisoformat(r["due_date"])
                if due<today: result.append({"level":"OVERDUE","message":f'{r["item"]} in {r["list_name"]} was due {due.isoformat()}.'})
            except ValueError: pass
    totals=defaultdict(float)
    for r in records:
        try: totals[r["category"]]+=float(r["quantity"])
        except (ValueError,TypeError): pass
    for cat,total in totals.items():
        limit=CATEGORY_LIMITS.get(cat,10)
        if total>limit: result.append({"level":"CRITICAL LIMIT","message":f"{cat} quantity total {total:g} exceeds demo threshold {limit:g}."})
    return result

def import_csv(path, records):
    path=Path(path); accepted=[]; errors=[]
    try:
        with path.open(newline="",encoding="utf-8-sig") as f:
            reader=csv.DictReader(f)
            if not reader.fieldnames: raise ValidationError("CSV has no header row.")
            missing=REQUIRED-set(reader.fieldnames)
            if missing: raise ValidationError("Missing columns: "+", ".join(sorted(missing)))
            for line,row in enumerate(reader,start=2):
                try: accepted.append(validate_record(row))
                except ValidationError as exc: errors.append({"row":line,"error":str(exc)})
    except OSError as exc: raise ValidationError(f"Cannot open CSV: {exc}") from exc
    records.extend(accepted); save_records(records)
    return accepted,errors

def export_all(records, prefix="grocery_report"):
    EXPORTS.mkdir(exist_ok=True)
    stamp=datetime.now().strftime("%Y%m%d_%H%M%S")
    csv_path=EXPORTS/f"{prefix}_{stamp}.csv"
    with csv_path.open("w",newline="",encoding="utf-8") as f:
        w=csv.DictWriter(f,fieldnames=list(REQUIRED));w.writeheader();w.writerows(records)
    s=summary(records)
    md=EXPORTS/f"{prefix}_{stamp}.md"
    md.write_text("# Grocery List Summary\n\n"+f'- Total items: {s["total_items"]}\n- Purchased: {s["purchased"]}\n- Pending: {s["pending"]}\n- Purchase rate: {s["purchase_rate"]}%\n- Average quantity: {s["average_quantity"]}\n\n## Category counts\n'+"\n".join(f"- {k}: {v}" for k,v in s["category_counts"].items())+"\n",encoding="utf-8")
    txt=EXPORTS/f"{prefix}_{stamp}.txt"
    txt.write_text("GROCERY LIST AUDIT REPORT\n"+"="*28+"\n"+f'Total items: {s["total_items"]}\nPurchased: {s["purchased"]}\nPending: {s["pending"]}\nPurchase rate: {s["purchase_rate"]}%\nAverage quantity: {s["average_quantity"]}\n\nITEM AUDIT\n'+"\n".join(f'{r["id"]} | {r["item"]} | {r["category"]} | {r["quantity"]} {r["unit"]} | {"Purchased" if r["purchased"] else "Pending"}' for r in records)+"\n",encoding="utf-8")
    return [csv_path,md,txt]
