# Grocery List Generator — Project #69

**Domain:** Food & Agriculture  
**Technology:** Python 3.10+, CSV/JSON, Pandas, NumPy, Matplotlib (requirements installed), optional Streamlit interface.

## Project features mapped to the brief

### Must-have
1. **Interactive terminal interface:** menu-driven workflow in `main.py`.
2. **Defensive input validation:** blank checks, numeric quantity bounds, valid dates, supported boolean values and safe error messages.
3. **Core business logic:** choose a recipe and serving count to generate a categorized shopping list.
4. **Local persistence:** JSON primary data plus CSV mirror in `data/`.
5. **Record query and search:** keyword, category and purchase-status filters.
6. **Executive summary:** total, purchased, pending, purchase rate, average quantity and category metrics.

### Stretch features
1. **Multi-format export:** CSV, Markdown summary and TXT audit report in `exports/`.
2. **Threshold warning indicators:** overdue pending items and category quantity totals exceeding demo thresholds.
3. **GUI enhancement:** optional Streamlit browser interface in `app.py`.
4. **Bulk dataset import:** CSV schema checks and row-by-row validation error logs.

### Sample data
`data/records.json` and `data/records.csv` contain 40 realistic sample grocery entries. `data/recipes.json` contains 12 recipes.

## Run in VS Code (Windows PowerShell)

1. Extract the ZIP file.
2. Open VS Code → **File → Open Folder** → select `Grocery_List_Generator_Project`.
3. Open **Terminal → New Terminal**. Confirm the terminal is inside the project folder.
4. Check Python:
   ```powershell
   py --version
   ```
   Install Python 3.10 or newer if this command is unavailable. During installation, enable **Add Python to PATH**.
5. Create a virtual environment:
   ```powershell
   py -m venv .venv
   ```
6. Activate it:
   ```powershell
   .\.venv\Scripts\Activate.ps1
   ```
   If PowerShell blocks activation, use this for the current terminal only:
   ```powershell
   Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass
   .\.venv\Scripts\Activate.ps1
   ```
   Or skip activation and run `.\.venv\Scripts\python.exe` in place of `python`.
7. Install dependencies:
   ```powershell
   python -m pip install --upgrade pip
   python -m pip install -r requirements.txt
   ```

### Run the terminal application (main demo)
```powershell
python main.py
```

### Run the optional Streamlit interface
```powershell
python -m streamlit run app.py
```
A browser tab opens at the local Streamlit address. Keep the terminal running while demonstrating.

### Run tests
```powershell
python -m unittest discover -s tests -v
```

## Important VS Code notes
- Open the **outer project folder** that contains `main.py`, `app.py`, `grocery_core.py`, and `requirements.txt`.
- Do not run `streamlit run app.py` from a parent folder. Use `python -m streamlit run app.py` from the project root.
- If `requirements.txt` cannot be found, check the terminal path with `pwd` and open the correct folder.
- Keep `.venv` inside the project folder only if you want; it is excluded from the ZIP and should be recreated on each computer.
- Data is stored locally. Do not delete the `data` folder if you want to preserve the sample and saved entries.

## CSV import format
Required column headers:
`id,list_name,item,category,quantity,unit,purchased,due_date,created_at`

Dates must be `YYYY-MM-DD`. `purchased` must be true/false. Quantity must be greater than 0 and no more than 100000. Invalid rows are skipped and reported with their source row number.

## Demo flow (suggested)
1. Launch the CLI and view the menu.
2. Generate a grocery list from Vegetable Pulao for 4 servings.
3. View all items and search for `tomato`.
4. Mark an item as purchased.
5. View the executive summary and warning indicators.
6. Export CSV, Markdown and TXT reports.
7. Import a test CSV containing one valid row and one invalid row to show row-level validation.
8. Optionally launch Streamlit and demonstrate its Dashboard and Generate from Recipe pages.

## Limitations / honest demo notes
- The included sample data is demonstration data, not live supermarket inventory or prices.
- Category threshold values are configurable demo limits, not nutritional or financial advice.
- Recipe quantities are simple illustrative values and can be adjusted in `data/recipes.json`.
