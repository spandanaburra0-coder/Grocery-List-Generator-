import streamlit as st
import pandas as pd
from grocery_core import *
from analytics import analytics_metrics, category_figure, daily_trend_figure
st.set_page_config(page_title="Grocery List Generator",page_icon="🛒",layout="wide")
records=load_json()
st.title("🛒 Grocery List Generator")
st.caption("Project #69 | Food & Agriculture | Local Python application")
page=st.sidebar.radio("Navigation",["Dashboard","Generate from Recipe","All Items","Search & Filter","Import / Export","About"])
if page=="Dashboard":
    s=analytics_metrics(records); a,b,c,d,e=st.columns(5)
    a.metric("Total items",s["total"]);b.metric("Purchased",s["purchased"]);c.metric("Pending",s["pending"]);d.metric("Purchase rate",f'{s["purchase_rate"]}%');e.metric("Average quantity",s["average_quantity"])
    st.subheader("Category overview")
    st.pyplot(category_figure(records), use_container_width=True)
    st.subheader("Activity trend")
    st.pyplot(daily_trend_figure(records), use_container_width=True)
    st.subheader("Warnings")
    alerts=warnings(records)
    if alerts:
        for x in alerts: st.warning(f'{x["level"]}: {x["message"]}')
    else: st.success("No active warnings.")
elif page=="Generate from Recipe":
    recipes=load_recipes()
    with st.form("recipe"):
        name=st.selectbox("Recipe",list(recipes)); servings=st.number_input("Servings",1,100,2); list_name=st.text_input("Shopping list name","Meal Plan")
        submitted=st.form_submit_button("Generate grocery list")
    if submitted:
        try:
            added=generate_from_recipe(records,name,servings,list_name);st.success(f"Added {len(added)} ingredients.");st.dataframe(pd.DataFrame(added),use_container_width=True)
        except ValidationError as e: st.error(str(e))
elif page=="All Items":
    if records: st.dataframe(pd.DataFrame(records),use_container_width=True,hide_index=True)
    else: st.info("No grocery items saved.")
elif page=="Search & Filter":
    key=st.text_input("Search item, category or list")
    cats=["All"]+CATEGORIES; cat=st.selectbox("Category",cats)
    status=st.selectbox("Purchase status",["All","Pending","Purchased"])
    found=search_records(records,key,cat,"All",status)
    st.write(f"{len(found)} result(s)")
    if found: st.dataframe(pd.DataFrame(found),use_container_width=True,hide_index=True)
    else: st.info("No matching items.")
elif page=="Import / Export":
    uploaded=st.file_uploader("Import legacy CSV",type=["csv"])
    if uploaded and st.button("Validate and import CSV"):
        temp=ROOT/"data"/"uploaded_import.csv";temp.write_bytes(uploaded.getvalue())
        try:
            good,bad=import_csv(temp,records);st.success(f"Imported {len(good)} row(s).")
            if bad: st.dataframe(pd.DataFrame(bad))
        except ValidationError as e: st.error(str(e))
    st.write("Export current data")
    if st.button("Generate CSV, Markdown and TXT reports"):
        paths=export_all(records)
        for p in paths:
            st.write(p.name)
            st.download_button(f"Download {p.suffix.upper()}",p.read_bytes(),file_name=p.name)
else:
    st.markdown("""
    **Purpose:** create categorized shopping lists from selected recipes, maintain local records,
    search lists, calculate summary metrics and export reports.

    **Storage:** `data/records.json` and `data/records.csv`.

    **CLI demo:** run `python main.py` in the VS Code terminal.
    """)
    st.write("Recipe library:",", ".join(load_recipes().keys()))
